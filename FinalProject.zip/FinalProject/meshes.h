//Paul Kim Final Project

#include <GL/glew.h>
#include <glm/glm.hpp>

class Meshes
{
	// Stores the GL data relative to a given mesh
	struct GLMesh
	{
		GLuint vao;         // For vertex array object (VAO)
		GLuint vbos[2];     // For vertex buffer objects (VBO)
		GLuint nVertices;	// Number of vertices for the mesh
		GLuint nIndices;    // Number of indices for the mesh
	};

public:
	GLMesh gCubeMesh;
	GLMesh gCylinderMesh;
	GLMesh gConicalFrustumMesh;
	GLMesh gConeMesh;
	GLMesh gCircularPlaneMesh;
	GLMesh gOpenCylinderMesh; 
	GLMesh gTorusMesh;


public:
	void CreateMesh();
	void DestroyMesh();

private:
	void UCreateCubeMesh(GLMesh &mesh);
	void UCreateCylinderMesh(GLMesh &mesh);
	void UCreateOpenCylinderMesh(GLMesh &mesh);
	void UCreateConicalFrustumMesh(GLMesh &mesh);
	void UCreateCircularPlaneMesh(GLMesh &mesh);
	void UCreateTorusMesh(GLMesh &mesh);
	void UDestroyMesh(GLMesh &mesh);

};