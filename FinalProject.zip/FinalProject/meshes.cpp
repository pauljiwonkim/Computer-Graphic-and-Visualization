//Paul Kim Final Project
#include "meshes.h"
#include <vector>
#include <cmath>

struct Vertex {
    float position[3];
    float normal[3];
    float texCoords[2];
};

void Meshes::CreateMesh()
{
	UCreateCubeMesh(gCubeMesh);
	UCreateCylinderMesh(gCylinderMesh);
    UCreateOpenCylinderMesh(gOpenCylinderMesh);
    UCreateConicalFrustumMesh(gConicalFrustumMesh);
    UCreateCircularPlaneMesh(gCircularPlaneMesh);
    UCreateTorusMesh(gTorusMesh);
}

void Meshes::DestroyMesh()
{
	UDestroyMesh(gCubeMesh);
	UDestroyMesh(gCylinderMesh);
    UDestroyMesh(gOpenCylinderMesh);
	UDestroyMesh(gConeMesh);
    UDestroyMesh(gConicalFrustumMesh);
    UDestroyMesh(gCircularPlaneMesh);
    UDestroyMesh(gTorusMesh);
}

void Meshes::UCreateCircularPlaneMesh(GLMesh &mesh) {
    const GLuint sidesNum = 16; // Number of sides for the circle (Adjustable)
    const float PI = 3.14159265358979323846264f;

    // Calculate the total number of vertices needed
    Vertex verts[sidesNum + 1];

    // Calculate the total number of indices needed
    GLuint indices[sidesNum * 3];

    // Vertex data
    float radius = 0.49f;
    float angleIncrement = 2 * PI / sidesNum;

    // Calculations for normals and texture coordinates
    for (GLuint i = 0; i <= sidesNum; ++i) {

        //Calculate vertex's angle 
        float angle = i * angleIncrement;

        //Calculate x and z coordinates based on angle and radius
        float x = radius * cos(angle);
        float z = radius * sin(angle);

        // Base vertex
        // Set the positions
        verts[i].position[0] = x;
        verts[i].position[1] = 0.0f; // Height is set to 0 for flat plane
        verts[i].position[2] = z;

        // Set the normals
        verts[i].normal[0] = 0.0f;
        verts[i].normal[1] = 1.0f; // Normals point straight up for flat plane
        verts[i].normal[2] = 0.0f;

        //Set the texture coordinates
        verts[i].texCoords[0] = x + 0.5f;
        verts[i].texCoords[1] = z + 0.5f;
    }

    // Indices
    for (GLuint i = 0; i < sidesNum; ++i) {
        
        indices[i * 3] = i + 1;
        indices[i * 3 + 1] = 0;
        indices[i * 3 + 2] = (i + 1) % sidesNum + 1;
    }

    mesh.nVertices = sizeof(indices) / sizeof(indices[0]);

    // Create VAO
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    // Create VBO for vertex data
    glGenBuffers(1, &mesh.vbos[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    // Vertex attribute pointers for vertex positions
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, position));
    glEnableVertexAttribArray(0);
    // Vertex attribute pointers for normals
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, normal));
    glEnableVertexAttribArray(1);
    // Vertex attribute pointers for texture coordinates
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, texCoords));
    glEnableVertexAttribArray(2);

    glGenBuffers(1, &mesh.vbos[1]); 
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    glBindVertexArray(0);
}

void Meshes::UCreateCubeMesh(GLMesh &mesh)
{
	// Position and Color data
	GLfloat verts[] = {
		//Positions				//Normals							//Texture Coordinates
		
		//Top Face					//Positive Y Normal
		-0.5f,  0.5f, -0.5f,		0.0f,  1.0f,  0.0f,				0.0f, 1.0f,
		-0.5f,  0.5f, 0.5f,			0.0f,  1.0f,  0.0f,				0.0f, 0.0f,
		0.5f,  0.5f,  0.5f,			0.0f,  1.0f,  0.0f,				1.0f, 0.0f,
		0.5f,  0.5f,  -0.5f,		0.0f,  1.0f,  0.0f,				1.0f, 1.0f,

		//Bottom Face				//Negative Y Normal
		-0.5f, -0.5f, 0.5f,			0.0f, -1.0f,  0.0f,				0.0f, 1.0f,
		-0.5f, -0.5f, -0.5f,		0.0f, -1.0f,  0.0f,				0.0f, 0.0f,
		0.5f, -0.5f, -0.5f,			0.0f, -1.0f,  0.0f,				1.0f, 0.0f,
		0.5f, -0.5f,  0.5f,			0.0f, -1.0f,  0.0f,				1.0f, 1.0f,

		//Front Face				//Positive Z Normal
		-0.5f, 0.5f,  0.5f,			0.0f,  0.0f,  1.0f,				0.0f, 1.0f,
		-0.5f, -0.5f,  0.5f,		0.0f,  0.0f,  1.0f,				0.0f, 0.0f,
		0.5f,  -0.5f,  0.5f,		0.0f,  0.0f,  1.0f,				1.0f, 0.0f,
		0.5f,  0.5f,  0.5f,			0.0f,  0.0f,  1.0f,				1.0f, 1.0f,

		//Back Face					//Negative Z Normal				
		0.5f, 0.5f, -0.5f,			0.0f,  0.0f, -1.0f,				0.0f, 1.0f,
		0.5f, -0.5f, -0.5f,			0.0f,  0.0f, -1.0f,				0.0f, 0.0f,
		-0.5f, -0.5f, -0.5f,		0.0f,  0.0f, -1.0f,				1.0f, 0.0f,
		-0.5f, 0.5f, -0.5f,			0.0f,  0.0f, -1.0f,				1.0f, 1.0f,

		//Left Face					//Negative X Normal
		-0.5f, 0.5f, -0.5f,			1.0f,  0.0f,  0.0f,				0.0f, 1.0f,
		-0.5f, -0.5f,  -0.5f,		1.0f,  0.0f,  0.0f,				0.0f, 0.0f,
		-0.5f,  -0.5f,  0.5f,		1.0f,  0.0f,  0.0f,				1.0f, 0.0f,
		-0.5f,  0.5f,  0.5f,		1.0f,  0.0f,  0.0f,				1.0f, 1.0f,

		//Right Face				//Positive X Normal
		0.5f,  0.5f,  0.5f,			1.0f,  0.0f,  0.0f,				0.0f, 1.0f,
		0.5f,  -0.5f, 0.5f,			1.0f,  0.0f,  0.0f,				0.0f, 0.0f,
		0.5f, -0.5f, -0.5f,			1.0f,  0.0f,  0.0f,				1.0f, 0.0f,
		0.5f, 0.5f, -0.5f,			1.0f,  0.0f,  0.0f,				1.0f, 1.0f,
	};

	// Index data
	GLuint indices[] = {
			0,1,2,
			0,2,3,
			4,5,6,
			4,6,7,
			8,9,10,
			8,10,11,
			12,13,14,
			12,14,15,
			16,17,18,
			16,18,19,
			20,21,22,
			20,22,23
	};

	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerNormal = 3;
	const GLuint floatsPerUV = 2;

	mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));
	mesh.nIndices = sizeof(indices) / sizeof(indices[0]);

	glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
	glBindVertexArray(mesh.vao);

	// Create 2 buffers: first one for the vertex data; second one for the indices
	glGenBuffers(2, mesh.vbos);
	glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]); // Activates the buffer
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

	// Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

	// Create Vertex Attribute Pointers
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);

	glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
	glEnableVertexAttribArray(1);

	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
	glEnableVertexAttribArray(2);
}

void Meshes::UCreateCylinderMesh(GLMesh &mesh) {
    const GLuint sidesNum = 16; // Number of sides for the cylinder (Adjustable)
    const float PI = 3.14159265358979323846264f;

    // Calculate the total number of vertices needed
    Vertex verts[(sidesNum + 1) * 2];

    // Calculate the total number of indices needed
    GLuint indices[sidesNum * 3 * 4];

    // Vertex data
    float radius = 0.44f; 
    float height = 1.0f;
    float angleIncrement = 2 * PI / sidesNum; // Angle Increment for each sides

    // Calculations for normals and texture coordinates
    for (GLuint i = 0; i <= sidesNum; ++i) {

        //Calculate vertex's angle 
        float angle = i * angleIncrement;

        //Calculate base vertex's x and y coords
        float x = radius * cos(angle);
        float z = radius * sin(angle);

        // Set positions, normals and texture coords for base vertex
        verts[i].position[0] = x;
        verts[i].position[1] = -height / 2.0f;
        verts[i].position[2] = z;
        verts[i].normal[0] = 0.0f;
        verts[i].normal[1] = -1.0f;
        verts[i].normal[2] = 0.0f;
        verts[i].texCoords[0] = x + 0.5f;
        verts[i].texCoords[1] = z + 0.5f;

        // Set positions, normals and texture coords for top vertex
        verts[i + sidesNum + 1].position[0] = x;
        verts[i + sidesNum + 1].position[1] = height / 2.0f;
        verts[i + sidesNum + 1].position[2] = z;
        verts[i + sidesNum + 1].normal[0] = 0.0f;
        verts[i + sidesNum + 1].normal[1] = 1.0f;
        verts[i + sidesNum + 1].normal[2] = 0.0f;
        verts[i + sidesNum + 1].texCoords[0] = x + 0.5f;
        verts[i + sidesNum + 1].texCoords[1] = z + 0.5f;
    }

    // Top indices
    for (GLuint i = 0; i < sidesNum; ++i) {
        indices[(sidesNum * 3) + i * 3] = (i + 1) % sidesNum + (sidesNum + 1);
        indices[(sidesNum * 3) + i * 3 + 1] = (sidesNum + 1);
        indices[(sidesNum * 3) + i * 3 + 2] = i + (sidesNum + 1);
    }

    // Base indices
    for (GLuint i = 0; i < sidesNum; ++i) {
        indices[i * 3] = i + 1;
        indices[i * 3 + 1] = 0;
        indices[i * 3 + 2] = (i + 1) % sidesNum + 1;
    }

    // Side indices
    for (GLuint i = 0; i < sidesNum; ++i) {
        int baseIndex = sidesNum * 3 * 2;
        indices[baseIndex + i * 3] = i;
        indices[baseIndex + i * 3 + 1] = (i + 1) % sidesNum;
        indices[baseIndex + i * 3 + 2] = i + (sidesNum + 1);

        indices[baseIndex + sidesNum * 3 + i * 3] = i + (sidesNum + 1);
        indices[baseIndex + sidesNum * 3 + i * 3 + 1] = (i + 1) % sidesNum;
        indices[baseIndex + sidesNum * 3 + i * 3 + 2] = (i + 1) % sidesNum + (sidesNum + 1);
    }

    mesh.nVertices = sizeof(indices) / sizeof(indices[0]);

    // Create VAO
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    // Create VBO for vertex data
    glGenBuffers(1, &mesh.vbos[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    // Vertex attribute pointers for vertex positions
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, position));
    glEnableVertexAttribArray(0);

    // Vertex attribute pointers for normals
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, normal));
    glEnableVertexAttribArray(1);

    // Vertex attribute pointers for texture coordinates
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, texCoords));
    glEnableVertexAttribArray(2);

    glGenBuffers(1, &mesh.vbos[1]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    glBindVertexArray(0);
}

void Meshes::UCreateConicalFrustumMesh(GLMesh &mesh) { 
    const GLuint sidesNum = 16; // Number of sides for the Conical Frustum (Adjustable)
    const float PI = 3.14159265358979323846264f;

    float topRadius = 0.12f;
    float bottomRadius = 0.445f;
    float height = 1.0f; 

    // Define vertex data arrays
    struct Vertex {
        glm::vec3 position;
        glm::vec3 normal;
        glm::vec2 texCoord;
    };

    // Calculate the total number of vertices needed
    Vertex verts[(sidesNum + 1) * 2]; 
    // Calculate the total number of indices needed
    GLuint indices[sidesNum * 6]; 

    // Generate vertices for top circle
    for (GLuint i = 0; i <= sidesNum; ++i) {

        //Calculate vertex's angle 
        float angle = i * 2 * PI / sidesNum;

        //Calculate  vertex's x and z coords
        float x = topRadius * cos(angle);
        float z = topRadius * sin(angle);

        // Set position, normal and texture coords
        verts[i].position = glm::vec3(x, height / 2.0f, z);
        verts[i].normal = glm::vec3(0.0f, 1.0f, 0.0f); // Normal for top circle
        verts[i].texCoord = glm::vec2(static_cast<float>(i) / sidesNum, 1.0f);
    }

    // Generate vertices for bottom circle
    for (GLuint i = 0; i <= sidesNum; ++i) {

        //Calculate vertex's angle 
        float angle = i * 2 * PI / sidesNum;
        float x = bottomRadius * cos(angle);
        float z = bottomRadius * sin(angle);

        verts[i + sidesNum + 1].position = glm::vec3(x, -height / 2.0f, z);
        verts[i + sidesNum + 1].normal = glm::vec3(0.0f, -1.0f, 0.0f); // Normal for bottom circle
        verts[i + sidesNum + 1].texCoord = glm::vec2(static_cast<float>(i) / sidesNum, 0.0f);
    }

    // Generate indices for triangles connecting top and bottom circles
    for (GLuint i = 0; i < sidesNum; ++i) {
        // Side triangles
        indices[i * 6] = i;
        indices[i * 6 + 1] = (i + 1) % sidesNum;
        indices[i * 6 + 2] = i + (sidesNum + 1);

        indices[i * 6 + 3] = (i + 1) % sidesNum + (sidesNum + 1);
        indices[i * 6 + 4] = (i + 1) % sidesNum;
        indices[i * 6 + 5] = i + (sidesNum + 1);
    }

    mesh.nVertices = sizeof(indices) / sizeof(indices[0]);

    // Create VAO
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    // Create VBO
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    // Vertex attribute pointers
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, position));
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, normal));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, texCoord));
    glEnableVertexAttribArray(2);

    // Create EBO (Element Buffer Object) for indices
    glGenBuffers(1, mesh.vbos + 1);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    glBindVertexArray(0);
}


void Meshes::UCreateOpenCylinderMesh(GLMesh &mesh) { // Same as ConicalFrustum Mesh but with equal top and bottom
    const GLuint sidesNum = 16; // Number of sides for the Conical Frustum (Adjustable)
    const float PI = 3.14159265358979323846264f;

    float topRadius = 0.5f; 
    float bottomRadius = 0.5f; 
    float height = 2.2f; 

    // Define vertex data arrays
    struct Vertex {
        glm::vec3 position;
        glm::vec3 normal;
        glm::vec2 texCoord;
    };

    // Calculate the total number of vertices needed
    Vertex verts[(sidesNum + 1) * 2]; 
    // Calculate the total number of indices needed
    GLuint indices[sidesNum * 6];

    // Generate vertices for top circle
    for (GLuint i = 0; i <= sidesNum; ++i) {
        float angle = i * 2 * PI / sidesNum;
        float x = topRadius * cos(angle);
        float z = topRadius * sin(angle);

        verts[i].position = glm::vec3(x, height / 2.0f, z);
        verts[i].normal = glm::vec3(0.0f, 1.0f, 0.0f); // Normal for top circle
        verts[i].texCoord = glm::vec2(static_cast<float>(i) / sidesNum, 1.0f);
    }

    // Generate vertices for bottom circle
    for (GLuint i = 0; i <= sidesNum; ++i) {
        float angle = i * 2 * PI / sidesNum;
        float x = bottomRadius * cos(angle);
        float z = bottomRadius * sin(angle);

        verts[i + sidesNum + 1].position = glm::vec3(x, -height / 2.0f, z);
        verts[i + sidesNum + 1].normal = glm::vec3(0.0f, -1.0f, 0.0f); // Normal for bottom circle
        verts[i + sidesNum + 1].texCoord = glm::vec2(static_cast<float>(i) / sidesNum, 0.0f);
    }

    // Generate indices for triangles connecting top and bottom circles
    for (GLuint i = 0; i < sidesNum; ++i) {
        // Side triangles
        indices[i * 6] = i;
        indices[i * 6 + 1] = (i + 1) % sidesNum;
        indices[i * 6 + 2] = i + (sidesNum + 1);

        indices[i * 6 + 3] = (i + 1) % sidesNum + (sidesNum + 1);
        indices[i * 6 + 4] = (i + 1) % sidesNum;
        indices[i * 6 + 5] = i + (sidesNum + 1);
    }

    mesh.nVertices = sizeof(indices) / sizeof(indices[0]);

    // Create VAO
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    // Create VBO
    glGenBuffers(1, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    // Vertex attribute pointers
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, position));
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, normal));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, texCoord));
    glEnableVertexAttribArray(2);

    glGenBuffers(1, mesh.vbos + 1);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    glBindVertexArray(0);
}

void Meshes::UCreateTorusMesh(GLMesh &mesh) { // Cut in half for cup handle
    const float outerRadius = 0.5f;
    const float innerRadius = 0.1f;
    const unsigned int numMajorSegments = 16;
    const unsigned int numMinorSegments = 16;

    // Calculate the total number of vertices needed
    unsigned int totalVertices = numMajorSegments * numMinorSegments;
    // Calculate the total number of indices needed
    unsigned int totalIndices = numMajorSegments * numMinorSegments * 6;

    // Memory
    Vertex* verts = new Vertex[totalVertices];
    GLuint* indices = new GLuint[totalIndices];

    const float PI = 3.14159265358979323846264f;
    float majorAngleIncrement = 2.0f * PI / numMajorSegments;
    float minorAngleIncrement = 2.0f * PI / numMinorSegments;

    unsigned int vertexIndex = 0;
    for (unsigned int i = 0; i < numMajorSegments; ++i) {
        float majorAngle = i * majorAngleIncrement;
        float cosMajor = cos(majorAngle);
        float sinMajor = sin(majorAngle);

        for (unsigned int j = 0; j < numMinorSegments; ++j) {
            float minorAngle = j * minorAngleIncrement;
            float cosMinor = cos(minorAngle);
            float sinMinor = sin(minorAngle);

            // Calculate positions, normals and textuire coords
            verts[vertexIndex].position[0] = (outerRadius + innerRadius * cosMinor) * cosMajor;
            verts[vertexIndex].position[1] = innerRadius * sinMinor;
            verts[vertexIndex].position[2] = (outerRadius + innerRadius * cosMinor) * sinMajor;

            verts[vertexIndex].normal[0] = cosMajor * cosMinor;
            verts[vertexIndex].normal[1] = sinMinor;
            verts[vertexIndex].normal[2] = sinMajor * cosMinor;

            verts[vertexIndex].texCoords[0] = static_cast<float>(i) / numMajorSegments;
            verts[vertexIndex].texCoords[1] = static_cast<float>(j) / numMinorSegments;

            ++vertexIndex;
        }
    }

    //Generate indices for triangles
    unsigned int index = 0;
    for (unsigned int i = 0; i < numMajorSegments; ++i) {
        for (unsigned int j = 0; j < numMinorSegments; ++j) {
            unsigned int nextI = (i + 1) % numMajorSegments;
            unsigned int nextJ = (j + 1) % numMinorSegments;

            indices[index++] = i * numMinorSegments + j;
            indices[index++] = i * numMinorSegments + nextJ;
            indices[index++] = nextI * numMinorSegments + j;

            indices[index++] = i * numMinorSegments + nextJ;
            indices[index++] = nextI * numMinorSegments + nextJ;
            indices[index++] = (nextI * numMinorSegments + j);
        }
    }

    mesh.nVertices = totalIndices / 2;

    // Create VAO
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    // Create VBO for vertex data
    glGenBuffers(1, &mesh.vbos[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]);
    glBufferData(GL_ARRAY_BUFFER, totalVertices * sizeof(Vertex), verts, GL_STATIC_DRAW);

    // Vertex attribute pointers for vertex positions
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, position));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, normal));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)offsetof(Vertex, texCoords));
    glEnableVertexAttribArray(2);

    glGenBuffers(1, &mesh.vbos[1]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, totalIndices * sizeof(GLuint), indices, GL_STATIC_DRAW);
    glBindVertexArray(0);
}


void Meshes::UDestroyMesh(GLMesh &mesh)
{
	glDeleteVertexArrays(1, &mesh.vao);
	glDeleteBuffers(2, mesh.vbos);
}